# RobotExpressive

Model by [Tomás Laulhé](https://www.patreon.com/quaternius). Before using this
model on a project, consider supporting the creator's Patreon. CC0 1.0.

Modifications by [Don McCurdy](https://donmccurdy.com/):

- Added three facial expression morph targets
- Converted with FBX2GLTF
- Removed duplicate materials and reduced material metalness
